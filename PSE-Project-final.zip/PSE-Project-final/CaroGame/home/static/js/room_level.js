function seeRoomList() {
	var x = document.getElementById("level");
	if(x.style.display === "none") {
		x.style.display = "block";
	} else {
		x.style.display = "none";
	}
}