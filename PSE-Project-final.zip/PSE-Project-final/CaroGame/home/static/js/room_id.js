		var elements = document.getElementsByClassName("room-id");
		//for(var i=0; i<elements.length; i++) { 
	        elements[0].onclick = function(e) {
	            var roomName = elements[0].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[1].onclick = function(e) {
	            var roomName = elements[1].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[2].onclick = function(e) {
	            var roomName = elements[2].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[3].onclick = function(e) {
	            var roomName = elements[3].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[4].onclick = function(e) {
	            var roomName = elements[4].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[5].onclick = function(e) {
	            var roomName = elements[5].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[6].onclick = function(e) {
	            var roomName = elements[6].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[7].onclick = function(e) {
	            var roomName = elements[7].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[8].onclick = function(e) {
	            var roomName = elements[8].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
	        elements[9].onclick = function(e) {
	            var roomName = elements[9].name;
	            window.location.pathname = '/caro/' + roomName + '/';
	        };
