from django.apps import AppConfig


class CaroConfig(AppConfig):
    name = 'caro'
