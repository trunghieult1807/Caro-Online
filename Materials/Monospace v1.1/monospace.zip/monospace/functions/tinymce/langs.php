<script type="text/javascript">
tinyMCE.addI18n({en:{
systempanel:{	
desc : 'System shortcodes'
}}});
</script>